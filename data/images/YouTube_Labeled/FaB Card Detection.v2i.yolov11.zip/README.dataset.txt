# FaB Card Detection > 2025-08-27 1:38pm
https://universe.roboflow.com/michael-bocph/fab-card-detection-21c8i

Provided by a Roboflow user
License: CC BY 4.0

