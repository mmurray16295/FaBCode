# FaB Card Live Detector

Real-time Flesh and Blood card detection using YOLO.

## Quick Start

### Installation

1. Install Python 3.8 or later
2. Install dependencies:
```bash
pip install -r requirements.txt
```

### Usage

**GUI Mode (Recommended):**
```bash
python fab_detector_app.py
```

This launches a user-friendly GUI where you can:
- Select detection mode (Windowed or Transparent Overlay)
- Configure monitors for multi-monitor setups
- Adjust confidence and IOU thresholds
- Enable/disable transparency and click-through
- Save/load your settings

**Command-Line Mode:**

Webcam Detection:
```bash
python live_detector.py --source webcam
```

Screen Capture Detection:
```bash
python live_detector.py --source screen
```

Test on Image:
```bash
python live_detector.py --source examples/test_image.jpg
```

Custom Model:
```bash
python live_detector.py --source webcam --model models/best.pt
```

## Controls

**GUI Mode:**
- Start/Stop buttons to control detection
- Settings persist between sessions
- Real-time FPS and card count display

**Command-Line Mode:**
- **'q'**: Quit
- **'c'**: Toggle confidence display

## Detection Modes

### Windowed Mode
Shows the captured screen with colored bounding boxes around detected cards.
- Green boxes around all detected cards
- Card names displayed above each box
- Card preview appears below the box when you hover over it
- Useful for debugging and seeing all detections at once

### Transparent Overlay Mode
Creates an invisible window that only shows card previews when you hover over them.
- Perfect for playing online (e.g., webcam games)
- Minimal visual interference
- Optional click-through mode (mouse clicks pass through the window)
- Keep-on-top option ensures it's always visible

### Multi-Monitor Support
- **Capture Monitor**: Which screen to watch for cards
- **Display Monitor**: Where to show the detection window
- Ideal for dual-monitor setups (play on one, detect on the other)

## Command-Line Options

- `--source`: Detection source (webcam/screen/image path)
- `--model`: Path to model weights (default: models/best.pt)
- `--conf`: Confidence threshold 0-1 (default: 0.25)
- `--iou`: IOU threshold for NMS (default: 0.45)
- `--camera`: Camera device ID for webcam (default: 0)
- `--monitor`: Monitor number for screen capture (default: 1)
- `--scale`: Display scale for screen capture (default: 0.5)
- `--save`: Save annotated image path (image mode only)

## Examples

**High confidence detection:**
```bash
python live_detector.py --source webcam --conf 0.5
```

**Screen capture on second monitor:**
```bash
python live_detector.py --source screen --monitor 2
```

**Batch process images:**
```bash
for img in examples/*.jpg; do
    python live_detector.py --source "$img" --save "output_$(basename $img)"
done
```

## Model Information

This model was trained on synthetic FaB card images with:
- YOLOv11 nano architecture
- Image size: 1280px
- Top 100 most popular cards
- Synthetic playmat backgrounds

See `models/training_args.yaml` for full training configuration.

## Troubleshooting

**No webcam found:**
- Try different camera IDs: `--camera 1`, `--camera 2`, etc.
- Check camera permissions

**Screen capture not working:**
- On macOS: Grant screen recording permission
- On Linux: May need X11 or Wayland configuration

**Slow detection:**
- Reduce image size internally (modify code)
- Use GPU-enabled PyTorch: `pip install torch --index-url https://download.pytorch.org/whl/cu118`

**Model not found:**
- Ensure `models/best.pt` exists
- Or specify custom path: `--model path/to/model.pt`

## System Requirements

- **CPU**: Any modern CPU (Intel/AMD/ARM)
- **RAM**: 4GB minimum, 8GB recommended
- **GPU**: Optional (NVIDIA with CUDA for faster inference)
- **Storage**: ~100MB for model and dependencies

## Performance

- **CPU-only**: 5-15 FPS (Intel i5/i7)
- **With GPU**: 30-60 FPS (NVIDIA GTX 1060+)

## License

Model and code for personal/educational use.
